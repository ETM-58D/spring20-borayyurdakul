# Example Progress Journal

## Week 0 (10 April)

[Here](files/interesting_example.html) is my interesting R example.

## Week 13 (4 May)

[Q1 Answers](files/hw1q1.html) for the HW1.

[Q2 Answers](files/hw1q2.html) for the HW1.

[Q3 Answers](files/hw1q3.html) for the HW1.